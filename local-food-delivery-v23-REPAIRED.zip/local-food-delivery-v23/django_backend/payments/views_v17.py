from django.conf import settings
from django.db import transaction
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.response import Response
from .models import Payment
from .serializers import PaymentSerializer
from .gateway import create_order, verify_payment_signature, verify_webhook_signature, GatewayError
from orders.models import Order

class CreateGatewayOrderView(APIView):
    permission_classes=[IsAuthenticated]
    @transaction.atomic
    def post(self,request,order_id):
        try: order=Order.objects.select_for_update().get(id=order_id,customer=request.user)
        except Order.DoesNotExist: return Response({'detail':'Order not found'},status=404)
        if order.status=='CANCELLED': return Response({'detail':'Cancelled order cannot be paid'},status=400)
        payment,_=Payment.objects.get_or_create(order=order,defaults={'customer':request.user,'method':'ONLINE','amount':order.total})
        if payment.status=='SUCCESS': return Response(PaymentSerializer(payment).data)
        payment.method='ONLINE'; payment.amount=order.total; payment.provider='razorpay'
        try: gateway_order=create_order(amount=order.total,receipt=f'order_{order.id}')
        except GatewayError as exc: return Response({'detail':str(exc)},status=503)
        payment.save(update_fields=['method','amount','provider','updated_at'])
        return Response({'payment':PaymentSerializer(payment).data,'gateway':{'key_id':settings.RAZORPAY_KEY_ID,'order_id':gateway_order['id'],'amount':gateway_order['amount'],'currency':gateway_order['currency']}})

class VerifyGatewayPaymentView(APIView):
    permission_classes=[IsAuthenticated]
    @transaction.atomic
    def post(self,request,order_id):
        try: p=Payment.objects.select_for_update().get(order_id=order_id,customer=request.user,method='ONLINE')
        except Payment.DoesNotExist: return Response({'detail':'Payment not found'},status=404)
        gateway_order_id=request.data.get('gateway_order_id'); payment_id=request.data.get('payment_id'); signature=request.data.get('signature')
        if not gateway_order_id or not payment_id or not verify_payment_signature(order_id=gateway_order_id,payment_id=payment_id,signature=signature):
            p.status='FAILED'; p.save(update_fields=['status','updated_at'])
            return Response({'detail':'Invalid payment signature'},status=400)
        p.provider_payment_id=payment_id; p.status='SUCCESS'; p.save(update_fields=['provider_payment_id','status','updated_at'])
        return Response(PaymentSerializer(p).data)

class RazorpayWebhookView(APIView):
    permission_classes=[AllowAny]; authentication_classes=[]
    @transaction.atomic
    def post(self,request):
        signature=request.headers.get('X-Razorpay-Signature','')
        if not verify_webhook_signature(request.body,signature): return Response({'detail':'Invalid webhook signature'},status=400)
        event=request.data.get('event',''); entity=request.data.get('payload',{}).get('payment',{}).get('entity',{})
        payment_id=entity.get('id')
        if event not in ('payment.captured','payment.failed') or not payment_id: return Response({'received':True})
        status='SUCCESS' if event=='payment.captured' else 'FAILED'
        Payment.objects.filter(provider='razorpay',provider_payment_id=payment_id).update(status=status)
        return Response({'received':True})
