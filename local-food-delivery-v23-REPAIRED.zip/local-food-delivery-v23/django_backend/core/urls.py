from django.urls import path
from .admin_api import AdminDashboardView, PlatformSettingsView, AdminRestaurantListView, AdminDeliveryListView, AdminOrdersView, BrandingSettingsView, PublicBrandingView, AdminAdsView, AdminAdDetailView, PublicAdsView
urlpatterns=[
 path("dashboard/",AdminDashboardView.as_view()),
 path("settings/",PlatformSettingsView.as_view()),
 path("branding/",BrandingSettingsView.as_view()),
 path("restaurants/",AdminRestaurantListView.as_view()),
 path("restaurants/<int:pk>/",AdminRestaurantListView.as_view()),
 path("delivery/",AdminDeliveryListView.as_view()),
 path("delivery/<int:pk>/",AdminDeliveryListView.as_view()),
 path("orders/",AdminOrdersView.as_view()),
 path("ads/",AdminAdsView.as_view()),
 path("ads/<int:pk>/",AdminAdDetailView.as_view()),
 path("public/branding/",PublicBrandingView.as_view()),
 path("public/ads/",PublicAdsView.as_view()),
]
