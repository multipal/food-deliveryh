from django.conf import settings
from django.db import models
from restaurants.models import Restaurant, Product

class Order(models.Model):
    STATUS=[
        ("PLACED","Placed"),("ACCEPTED","Accepted"),("PREPARING","Preparing"),
        ("READY","Ready"),("PICKED_UP","Picked Up"),("OUT_FOR_DELIVERY","Out for Delivery"),
        ("DELIVERED","Delivered"),("CANCELLED","Cancelled")
    ]
    customer=models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.PROTECT,related_name="orders")
    restaurant=models.ForeignKey(Restaurant,on_delete=models.PROTECT,related_name="orders")
    status=models.CharField(max_length=30,choices=STATUS,default="PLACED")
    delivery_address=models.TextField()
    delivery_latitude=models.FloatField()
    delivery_longitude=models.FloatField()
    subtotal=models.DecimalField(max_digits=10,decimal_places=2,default=0)
    delivery_fee=models.DecimalField(max_digits=10,decimal_places=2,default=0)
    total=models.DecimalField(max_digits=10,decimal_places=2,default=0)
    commission=models.DecimalField(max_digits=10,decimal_places=2,default=0)
    created_at=models.DateTimeField(auto_now_add=True)

class OrderItem(models.Model):
    order=models.ForeignKey(Order,on_delete=models.CASCADE,related_name="items")
    product=models.ForeignKey(Product,on_delete=models.PROTECT)
    quantity=models.PositiveIntegerField()
    price=models.DecimalField(max_digits=10,decimal_places=2)
