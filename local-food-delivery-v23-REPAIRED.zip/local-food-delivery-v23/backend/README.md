# V5 Backend Contract

This folder defines the production backend boundary. It is intentionally framework-neutral so it can later be implemented in Django, Laravel/PHP, Node.js, etc.

Roles:
- customer
- restaurant
- delivery
- admin

Rules:
- Customer never receives service-radius/distance data in customer-facing responses.
- Backend must verify restaurant eligibility against the configured service radius.
- Order state transitions must be role-checked.
- Passwords must be hashed using the backend's secure password hashing facility.
- Authentication should use secure, expiring sessions or signed access tokens.
