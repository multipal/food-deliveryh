from django.db import models
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import Restaurant, Product
from .serializers import RestaurantSerializer, ProductSerializer

class RestaurantListView(APIView):
    permission_classes=[AllowAny]
    def get(self, request):
        qs=Restaurant.objects.filter(status="approved",is_open=True)
        q=request.query_params.get("q","").strip()
        if q:
            qs=qs.filter(models.Q(name__icontains=q) | models.Q(products__name__icontains=q)).distinct()
        lat=request.query_params.get("lat"); lng=request.query_params.get("lng")
        if lat is not None and lng is not None:
            try: lat=float(lat); lng=float(lng)
            except ValueError: return Response({"detail":"Invalid coordinates."},status=400)
            qs=[r for r in qs if r.distance_km(lat,lng)<=15]
        return Response(RestaurantSerializer(qs,many=True).data)

class ServiceCheckView(APIView):
    permission_classes=[AllowAny]
    def post(self, request):
        try:
            lat=float(request.data["latitude"]); lng=float(request.data["longitude"])
            rid=int(request.data["restaurant_id"])
            r=Restaurant.objects.get(id=rid,status="approved")
        except Exception:
            return Response({"eligible":False},status=400)
        return Response({"eligible": r.distance_km(lat,lng)<=15})

class RestaurantDetailView(generics.RetrieveAPIView):
    permission_classes=[AllowAny]
    queryset=Restaurant.objects.filter(status="approved")
    serializer_class=RestaurantSerializer

class MyRestaurantView(APIView):
    permission_classes=[IsAuthenticated]
    def get(self, request):
        if request.user.role!="restaurant" or not request.user.is_approved:
            return Response({"detail":"Forbidden"},status=403)
        r=Restaurant.objects.filter(owner=request.user).first()
        if not r: return Response({"detail":"Profile not created"},status=404)
        return Response(RestaurantSerializer(r).data)

class MyProductsView(APIView):
    permission_classes=[IsAuthenticated]
    def _restaurant(self, request):
        if request.user.role!="restaurant" or not request.user.is_approved:
            return None
        return Restaurant.objects.filter(owner=request.user,status="approved").first()
    def get(self, request):
        r=self._restaurant(request)
        if not r: return Response({"detail":"Forbidden"},status=403)
        return Response(ProductSerializer(r.products.all().order_by("id"),many=True).data)
    def post(self, request):
        r=self._restaurant(request)
        if not r: return Response({"detail":"Forbidden"},status=403)
        try: price=request.data["price"]
        except KeyError: return Response({"detail":"price is required"},status=400)
        p=Product.objects.create(restaurant=r,name=request.data.get("name",""),description=request.data.get("description",""),price=price,available=bool(request.data.get("available",True)))
        return Response(ProductSerializer(p).data,status=201)

class ProductAvailabilityView(APIView):
    permission_classes=[IsAuthenticated]
    def patch(self, request, pk):
        if request.user.role!="restaurant" or not request.user.is_approved:
            return Response({"detail":"Forbidden"},status=403)
        try: p=Product.objects.get(pk=pk,restaurant__owner=request.user,restaurant__status="approved")
        except Product.DoesNotExist: return Response({"detail":"Product not found"},status=404)
        p.available=bool(request.data.get("available"))
        p.save(update_fields=["available"])
        return Response(ProductSerializer(p).data)
