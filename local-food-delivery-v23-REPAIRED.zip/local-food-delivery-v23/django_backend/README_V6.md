# V6 — Real Django Backend Foundation

This version keeps the existing Zomato-style frontend and adds a real Django/DRF backend.

## Included
- Custom user roles: customer / restaurant / delivery / admin
- Secure Django password hashing
- Session + DRF token authentication
- Customer registration/login/logout/me
- Approved restaurant listing
- Backend-only 15 KM service-area enforcement
- Restaurant/product models
- Order model + role-controlled status transitions
- Delivery profile + assignment models
- Atomic delivery assignment acceptance
- WebP image compression targeting ~40 KB
- SQLite for easy local development

## Run
```bash
cd django_backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Open Django admin at `/admin/`.

## Important
The 15 KM rule is enforced on the server. The customer API does not return exact distance/radius.

For production, use PostgreSQL/PostGIS for scalable geospatial queries, HTTPS, a real secret key, production storage, payment gateway, SMS/WhatsApp provider, and proper deployment settings.
