from django.db import models

class PlatformSetting(models.Model):
    key = models.CharField(max_length=80, unique=True)
    value = models.CharField(max_length=255)
    updated_at = models.DateTimeField(auto_now=True)
    def __str__(self): return f"{self.key}={self.value}"

class Coupon(models.Model):
    code = models.CharField(max_length=40, unique=True)
    discount_type = models.CharField(max_length=10, choices=[("percent","Percent"),("flat","Flat")], default="percent")
    discount_value = models.DecimalField(max_digits=10, decimal_places=2)
    min_order = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

class PlatformAd(models.Model):
    PLACEMENTS=[("home","Customer Home"),("search","Search"),("restaurant","Restaurant/Menu"),("checkout","Checkout")]
    title=models.CharField(max_length=160)
    image_url=models.URLField(blank=True)
    target_url=models.URLField(blank=True)
    html_code=models.TextField(blank=True)
    placement=models.CharField(max_length=20,choices=PLACEMENTS,default="home")
    active=models.BooleanField(default=True)
    priority=models.PositiveIntegerField(default=10)
    starts_at=models.DateTimeField(null=True,blank=True)
    ends_at=models.DateTimeField(null=True,blank=True)
    created_at=models.DateTimeField(auto_now_add=True)
