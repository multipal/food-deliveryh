from decimal import Decimal
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from .models import PlatformSetting, Coupon
from restaurants.models import Restaurant
from delivery.models import DeliveryProfile
from orders.models import Order

DEFAULTS={"delivery_radius":"15","delivery_fee":"30","minimum_order":"100","commission":"10"}

def admin_only(request):
    return request.user.is_authenticated and request.user.role == "admin"

def setting(key):
    obj=PlatformSetting.objects.filter(key=key).first()
    return obj.value if obj else DEFAULTS.get(key,"")

class AdminDashboardView(APIView):
    permission_classes=[IsAuthenticated]
    def get(self,request):
        if not admin_only(request): return Response({"detail":"Forbidden"},status=403)
        return Response({
            "customers":request.user.__class__.objects.filter(role="customer").count(),
            "restaurants":Restaurant.objects.count(),
            "approved_restaurants":Restaurant.objects.filter(status="approved").count(),
            "pending_restaurants":Restaurant.objects.filter(status="pending").count(),
            "delivery_partners":DeliveryProfile.objects.count(),
            "approved_delivery":DeliveryProfile.objects.filter(approved=True).count(),
            "orders":Order.objects.count(),
            "active_orders":Order.objects.exclude(status__in=["DELIVERED","CANCELLED"]).count(),
        })

class PlatformSettingsView(APIView):
    permission_classes=[IsAuthenticated]
    def get(self,request):
        if not admin_only(request): return Response({"detail":"Forbidden"},status=403)
        return Response({k:setting(k) for k in DEFAULTS})
    def patch(self,request):
        if not admin_only(request): return Response({"detail":"Forbidden"},status=403)
        for k in DEFAULTS:
            if k in request.data:
                try:
                    value=Decimal(str(request.data[k]))
                    if value < 0: raise ValueError
                except Exception: return Response({"detail":f"Invalid {k}"},status=400)
                PlatformSetting.objects.update_or_create(key=k,defaults={"value":str(request.data[k])})
        return Response({k:setting(k) for k in DEFAULTS})

class AdminRestaurantListView(APIView):
    permission_classes=[IsAuthenticated]
    def get(self,request):
        if not admin_only(request): return Response({"detail":"Forbidden"},status=403)
        return Response(list(Restaurant.objects.values("id","name","status","is_open","owner_id","address")))
    def patch(self,request,pk):
        if not admin_only(request): return Response({"detail":"Forbidden"},status=403)
        try:r=Restaurant.objects.get(pk=pk)
        except Restaurant.DoesNotExist:return Response({"detail":"Not found"},status=404)
        status_value=request.data.get("status")
        if status_value in {"approved","rejected","suspended","pending"}: r.status=status_value
        if "is_open" in request.data: r.is_open=bool(request.data["is_open"])
        r.save(update_fields=["status","is_open"])
        return Response({"id":r.id,"status":r.status,"is_open":r.is_open})

class AdminDeliveryListView(APIView):
    permission_classes=[IsAuthenticated]
    def get(self,request):
        if not admin_only(request): return Response({"detail":"Forbidden"},status=403)
        return Response(list(DeliveryProfile.objects.values("id","user_id","approved","online","available")))
    def patch(self,request,pk):
        if not admin_only(request): return Response({"detail":"Forbidden"},status=403)
        try:p=DeliveryProfile.objects.get(pk=pk)
        except DeliveryProfile.DoesNotExist:return Response({"detail":"Not found"},status=404)
        if "approved" in request.data:p.approved=bool(request.data["approved"])
        p.save(update_fields=["approved"])
        return Response({"id":p.id,"approved":p.approved})

class AdminOrdersView(APIView):
    permission_classes=[IsAuthenticated]
    def get(self,request):
        if not admin_only(request): return Response({"detail":"Forbidden"},status=403)
        qs=Order.objects.select_related("restaurant","customer").order_by("-created_at")[:200]
        return Response([{"id":o.id,"status":o.status,"restaurant":o.restaurant.name,"customer_id":o.customer_id,"subtotal":str(o.subtotal),"delivery_fee":str(o.delivery_fee),"total":str(o.total),"commission":str(o.commission)} for o in qs])

from django.utils import timezone
from django.db import models
from .models import PlatformAd

BRANDING_DEFAULTS={
    "site_name":"Local Food",
    "site_logo_url":"",
    "adsense_enabled":"0",
    "adsense_client":"",
    "adsense_slot":"",
}

class BrandingSettingsView(APIView):
    permission_classes=[IsAuthenticated]
    def get(self,request):
        if not admin_only(request): return Response({"detail":"Forbidden"},status=403)
        return Response({k:setting(k) if k in DEFAULTS else (PlatformSetting.objects.filter(key=k).values_list("value",flat=True).first() or v) for k,v in BRANDING_DEFAULTS.items()})
    def patch(self,request):
        if not admin_only(request): return Response({"detail":"Forbidden"},status=403)
        allowed=set(BRANDING_DEFAULTS)
        for k,v in request.data.items():
            if k in allowed:
                PlatformSetting.objects.update_or_create(key=k,defaults={"value":str(v)})
        return self.get(request)

class PublicBrandingView(APIView):
    permission_classes=[]
    def get(self,request):
        return Response({k:(PlatformSetting.objects.filter(key=k).values_list("value",flat=True).first() or v) for k,v in BRANDING_DEFAULTS.items()})

class AdminAdsView(APIView):
    permission_classes=[IsAuthenticated]
    def get(self,request):
        if not admin_only(request): return Response({"detail":"Forbidden"},status=403)
        return Response(list(PlatformAd.objects.order_by("-priority","-id").values()))
    def post(self,request):
        if not admin_only(request): return Response({"detail":"Forbidden"},status=403)
        ad=PlatformAd.objects.create(
            title=request.data.get("title",""), image_url=request.data.get("image_url",""),
            target_url=request.data.get("target_url",""), html_code=request.data.get("html_code",""),
            placement=request.data.get("placement","home"), active=bool(request.data.get("active",True)),
            priority=int(request.data.get("priority",10)),
        )
        return Response({"id":ad.id,"title":ad.title},status=201)

class AdminAdDetailView(APIView):
    permission_classes=[IsAuthenticated]
    def patch(self,request,pk):
        if not admin_only(request): return Response({"detail":"Forbidden"},status=403)
        try: ad=PlatformAd.objects.get(pk=pk)
        except PlatformAd.DoesNotExist: return Response({"detail":"Not found"},status=404)
        for field in ["title","image_url","target_url","html_code","placement"]:
            if field in request.data: setattr(ad,field,request.data[field])
        if "active" in request.data: ad.active=bool(request.data["active"])
        if "priority" in request.data: ad.priority=int(request.data["priority"])
        ad.save()
        return Response({"id":ad.id,"active":ad.active})
    def delete(self,request,pk):
        if not admin_only(request): return Response({"detail":"Forbidden"},status=403)
        PlatformAd.objects.filter(pk=pk).delete(); return Response(status=204)

class PublicAdsView(APIView):
    permission_classes=[]
    def get(self,request):
        placement=request.query_params.get("placement","home")
        now=timezone.now()
        qs=PlatformAd.objects.filter(active=True,placement=placement).filter(
            models.Q(starts_at__isnull=True)|models.Q(starts_at__lte=now),
            models.Q(ends_at__isnull=True)|models.Q(ends_at__gte=now)
        ).order_by("-priority","-id")[:10]
        return Response(list(qs.values("id","title","image_url","target_url","html_code","placement")))
