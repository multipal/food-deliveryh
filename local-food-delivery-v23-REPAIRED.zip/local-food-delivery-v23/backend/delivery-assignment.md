# Delivery Assignment

When restaurant marks an order READY:

1. Find approved delivery partners who are online/available.
2. Apply service-area eligibility.
3. Rank candidates by configurable factors (availability, workload, proximity).
4. Offer the delivery.
5. Rider accepts.
6. Lock assignment to that rider.
7. Rider updates PICKED_UP -> OUT_FOR_DELIVERY -> DELIVERED.

A real implementation must use server-side authorization and atomic assignment to avoid two riders receiving the same order.
