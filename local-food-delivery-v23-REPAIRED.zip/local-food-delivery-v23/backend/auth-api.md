# Authentication API

POST /api/v1/auth/register
POST /api/v1/auth/login
POST /api/v1/auth/logout
GET  /api/v1/auth/me

Registration role policy:
- public registration: customer
- restaurant/delivery: application -> admin approval
- admin: never public registration

Login response:
{
  "user": {"id": 1, "role": "customer", "name": "..."},
  "access_token": "SERVER_GENERATED_TOKEN"
}
