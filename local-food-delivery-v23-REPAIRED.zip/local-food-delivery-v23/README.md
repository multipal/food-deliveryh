# Local Food Delivery V12
Zomato-style local food ordering prototype.

Customer: search -> restaurant -> menu -> cart -> checkout -> order.
Restaurant: view incoming orders and update basic status.

This is a frontend prototype. Production authentication, server database, payments, live GPS and secure backend validation are next.
