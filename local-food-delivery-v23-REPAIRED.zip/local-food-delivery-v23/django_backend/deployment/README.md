# Production Deployment Guide

Recommended architecture:
Browser -> HTTPS domain -> Django/Gunicorn -> PostgreSQL
                                  -> object/media storage

Before launch:
1. Set DEBUG=False.
2. Set a strong SECRET_KEY through environment variables.
3. Configure ALLOWED_HOSTS and CSRF trusted origins.
4. Use PostgreSQL for production.
5. Run migrations.
6. Collect static files.
7. Configure HTTPS.
8. Configure backups and logging.
9. Configure Razorpay production keys only after account verification.
10. Run Django security checks and end-to-end order/payment tests.
