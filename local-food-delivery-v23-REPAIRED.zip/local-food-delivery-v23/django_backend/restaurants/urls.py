from django.urls import path
from .views import RestaurantListView, RestaurantDetailView, ServiceCheckView, MyRestaurantView, MyProductsView, ProductAvailabilityView
urlpatterns=[
 path("",RestaurantListView.as_view()),
 path("service-check/",ServiceCheckView.as_view()),
 path("me/",MyRestaurantView.as_view()),
 path("me/products/",MyProductsView.as_view()),
 path("me/products/<int:pk>/availability/",ProductAvailabilityView.as_view()),
 path("<int:pk>/",RestaurantDetailView.as_view()),
]
