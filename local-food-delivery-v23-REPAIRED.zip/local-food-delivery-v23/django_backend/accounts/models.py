from django.contrib.auth.models import AbstractUser
from django.db import models

class User(AbstractUser):
    ROLE_CHOICES = [
        ("customer","Customer"),
        ("restaurant","Restaurant"),
        ("delivery","Delivery"),
        ("admin","Admin"),
    ]
    phone = models.CharField(max_length=20, unique=True, null=True, blank=True)
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default="customer")
    is_approved = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.username} ({self.role})"
