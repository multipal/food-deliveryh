from django.db import transaction
from .models import DeliveryProfile, DeliveryAssignment

def assign_ready_order(order):
    candidates=list(DeliveryProfile.objects.filter(approved=True,online=True,available=True))
    if not candidates: return None
    r=order.restaurant
    def score(p):
        if p.current_latitude is None or p.current_longitude is None: return (999999,p.id)
        return ((p.current_latitude-r.latitude)**2+(p.current_longitude-r.longitude)**2,p.id)
    candidates.sort(key=score)
    with transaction.atomic():
        rider=DeliveryProfile.objects.select_for_update().get(pk=candidates[0].pk)
        if not (rider.approved and rider.online and rider.available): return None
        a=DeliveryAssignment.objects.create(order=order,delivery_partner=rider,status="OFFERED")
        rider.available=False; rider.save(update_fields=["available"])
        return a
