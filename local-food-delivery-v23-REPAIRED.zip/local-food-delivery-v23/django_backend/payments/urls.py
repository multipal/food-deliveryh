from django.urls import path
from .views import CreatePaymentView, PaymentDetailView, PaymentWebhookView
from .views_v17 import CreateGatewayOrderView, VerifyGatewayPaymentView, RazorpayWebhookView
urlpatterns=[
 path('orders/<int:order_id>/pay/',CreatePaymentView.as_view()),
 path('orders/<int:order_id>/',PaymentDetailView.as_view()),
 path('webhook/',PaymentWebhookView.as_view()),
 path('orders/<int:order_id>/gateway-order/',CreateGatewayOrderView.as_view()),
 path('orders/<int:order_id>/verify/',VerifyGatewayPaymentView.as_view()),
 path('razorpay/webhook/',RazorpayWebhookView.as_view()),
]
