from django.contrib.auth import login, logout
from rest_framework import status
from rest_framework.authtoken.models import Token
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from .serializers import RegisterSerializer, LoginSerializer

class RegisterView(APIView):
    permission_classes=[AllowAny]
    def post(self, request):
        s=RegisterSerializer(data=request.data); s.is_valid(raise_exception=True)
        user=s.save()
        return Response({"id":user.id,"role":user.role}, status=status.HTTP_201_CREATED)

class LoginView(APIView):
    permission_classes=[AllowAny]
    def post(self, request):
        s=LoginSerializer(data=request.data); s.is_valid(raise_exception=True)
        user=s.validated_data["user"]; login(request,user)
        token,_=Token.objects.get_or_create(user=user)
        return Response({"token":token.key,"user_id":user.id,"role":user.role})

class LogoutView(APIView):
    def post(self, request):
        if hasattr(request.user,"auth_token"): request.user.auth_token.delete()
        logout(request)
        return Response({"ok":True})

class MeView(APIView):
    def get(self, request):
        u=request.user
        return Response({"id":u.id,"username":u.username,"email":u.email,"phone":u.phone,"role":u.role,"approved":u.is_approved})
