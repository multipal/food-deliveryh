import hashlib
import hmac
import os

class GatewayError(Exception):
    pass

def _razorpay_client():
    try:
        import razorpay
    except ImportError as exc:
        raise GatewayError("Install razorpay package to enable online payments") from exc
    key_id=os.getenv("RAZORPAY_KEY_ID", "")
    key_secret=os.getenv("RAZORPAY_KEY_SECRET", "")
    if not key_id or not key_secret:
        raise GatewayError("Razorpay credentials are not configured")
    return razorpay.Client(auth=(key_id,key_secret))

def create_order(*, amount, receipt):
    client=_razorpay_client()
    return client.order.create({"amount":int(round(float(amount)*100)),"currency":"INR","receipt":str(receipt),"payment_capture":1})

def verify_payment_signature(*, order_id, payment_id, signature):
    secret=os.getenv("RAZORPAY_KEY_SECRET","")
    if not secret or not signature: return False
    expected=hmac.new(secret.encode(),f"{order_id}|{payment_id}".encode(),hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected,signature)

def verify_webhook_signature(raw_body, signature):
    secret=os.getenv("RAZORPAY_WEBHOOK_SECRET","")
    if not secret or not signature: return False
    expected=hmac.new(secret.encode(),raw_body,hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected,signature)
