from rest_framework import serializers
from .models import Order, OrderItem

class OrderItemSerializer(serializers.ModelSerializer):
    class Meta:
        model=OrderItem
        fields=["id","product","quantity","price"]

class OrderSerializer(serializers.ModelSerializer):
    items=OrderItemSerializer(many=True,read_only=True)
    class Meta:
        model=Order
        fields=["id","restaurant","status","delivery_address","delivery_latitude","delivery_longitude","subtotal","delivery_fee","total","created_at","items"]
        read_only_fields=["status","customer","total"]
