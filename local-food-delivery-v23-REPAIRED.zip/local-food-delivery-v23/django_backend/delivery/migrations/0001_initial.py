from django.db import migrations, models
import django.db.models.deletion
from django.conf import settings
class Migration(migrations.Migration):
 initial=True
 dependencies=[('accounts','0001_initial'),('orders','0001_initial')]
 operations=[
 migrations.CreateModel(name='DeliveryProfile',fields=[('id',models.BigAutoField(auto_created=True,primary_key=True,serialize=False,verbose_name='ID')),('approved',models.BooleanField(default=False)),('online',models.BooleanField(default=False)),('available',models.BooleanField(default=True)),('current_latitude',models.FloatField(blank=True,null=True)),('current_longitude',models.FloatField(blank=True,null=True)),('last_location_at',models.DateTimeField(blank=True,null=True)),('created_at',models.DateTimeField(auto_now_add=True)),('user',models.OneToOneField(on_delete=django.db.models.deletion.CASCADE,related_name='delivery_profile',to=settings.AUTH_USER_MODEL))]),
 migrations.CreateModel(name='DeliveryAssignment',fields=[('id',models.BigAutoField(auto_created=True,primary_key=True,serialize=False,verbose_name='ID')),('status',models.CharField(choices=[('OFFERED','Offered'),('ACCEPTED','Accepted'),('PICKED_UP','Picked Up'),('OUT_FOR_DELIVERY','Out for Delivery'),('DELIVERED','Delivered'),('CANCELLED','Cancelled')],default='OFFERED',max_length=30)),('assigned_at',models.DateTimeField(auto_now_add=True)),('delivery_partner',models.ForeignKey(on_delete=django.db.models.deletion.PROTECT,related_name='assignments',to='delivery.deliveryprofile')),('order',models.OneToOneField(on_delete=django.db.models.deletion.CASCADE,related_name='delivery_assignment',to='orders.order'))])]
