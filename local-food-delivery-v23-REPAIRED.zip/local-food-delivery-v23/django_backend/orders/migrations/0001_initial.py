from django.db import migrations, models
import django.db.models.deletion

class Migration(migrations.Migration):
    initial=True
    dependencies=[('accounts','__first__'),('restaurants','__first__')]
    operations=[
        migrations.CreateModel(name='Order',fields=[
            ('id',models.BigAutoField(auto_created=True,primary_key=True,serialize=False,verbose_name='ID')),
            ('status',models.CharField(choices=[('PLACED','Placed'),('ACCEPTED','Accepted'),('PREPARING','Preparing'),('READY','Ready'),('PICKED_UP','Picked Up'),('OUT_FOR_DELIVERY','Out for Delivery'),('DELIVERED','Delivered'),('CANCELLED','Cancelled')],default='PLACED',max_length=30)),
            ('delivery_address',models.TextField()),('delivery_latitude',models.FloatField()),('delivery_longitude',models.FloatField()),
            ('subtotal',models.DecimalField(decimal_places=2,default=0,max_digits=10)),('delivery_fee',models.DecimalField(decimal_places=2,default=0,max_digits=10)),('total',models.DecimalField(decimal_places=2,default=0,max_digits=10)),('commission',models.DecimalField(decimal_places=2,default=0,max_digits=10)),('created_at',models.DateTimeField(auto_now_add=True)),
            ('customer',models.ForeignKey(on_delete=django.db.models.deletion.PROTECT,related_name='orders',to='accounts.user')),('restaurant',models.ForeignKey(on_delete=django.db.models.deletion.PROTECT,related_name='orders',to='restaurants.restaurant'))]),
        migrations.CreateModel(name='OrderItem',fields=[('id',models.BigAutoField(auto_created=True,primary_key=True,serialize=False,verbose_name='ID')),('quantity',models.PositiveIntegerField()),('price',models.DecimalField(decimal_places=2,max_digits=10)),('order',models.ForeignKey(on_delete=django.db.models.deletion.CASCADE,related_name='items',to='orders.order')),('product',models.ForeignKey(on_delete=django.db.models.deletion.PROTECT,to='restaurants.product'))]),
    ]
