from django.db import transaction
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from .models import Payment
from .serializers import PaymentSerializer
from orders.models import Order
from .views_v17 import CreateGatewayOrderView, VerifyGatewayPaymentView, RazorpayWebhookView

class CreatePaymentView(APIView):
    permission_classes=[IsAuthenticated]
    @transaction.atomic
    def post(self,request,order_id):
        try: order=Order.objects.select_for_update().get(id=order_id,customer=request.user)
        except Order.DoesNotExist: return Response({'detail':'Order not found'},status=404)
        if order.status=='CANCELLED': return Response({'detail':'Cancelled order cannot be paid'},status=400)
        method=request.data.get('method','COD')
        if method not in ('COD','ONLINE'): return Response({'detail':'Invalid payment method'},status=400)
        payment,created=Payment.objects.get_or_create(order=order,defaults={'customer':request.user,'method':method,'amount':order.total})
        if not created and payment.status=='SUCCESS': return Response(PaymentSerializer(payment).data)
        payment.method=method; payment.amount=order.total
        if method=='COD': payment.status='PENDING'; payment.provider='cod'
        else: payment.status='PENDING'; payment.provider='gateway_placeholder'
        payment.save()
        return Response(PaymentSerializer(payment).data,status=201 if created else 200)

class PaymentDetailView(APIView):
    permission_classes=[IsAuthenticated]
    def get(self,request,order_id):
        try: p=Payment.objects.get(order_id=order_id,customer=request.user)
        except Payment.DoesNotExist: return Response({'detail':'Payment not found'},status=404)
        return Response(PaymentSerializer(p).data)

class PaymentWebhookView(APIView):
    permission_classes=[]
    authentication_classes=[]
    @transaction.atomic
    def post(self,request):
        provider_id=request.data.get('provider_payment_id')
        order_id=request.data.get('order_id')
        status=request.data.get('status')
        if status not in ('SUCCESS','FAILED'): return Response({'detail':'Invalid status'},status=400)
        try: p=Payment.objects.select_for_update().get(order_id=order_id,provider_payment_id=provider_id)
        except Payment.DoesNotExist: return Response({'detail':'Payment not found'},status=404)
        p.status=status; p.save(update_fields=['status','updated_at'])
        return Response({'updated':True})
