from django.utils import timezone
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from .models import DeliveryProfile

class LocationUpdateView(APIView):
    permission_classes=[IsAuthenticated]
    def patch(self, request):
        if request.user.role != "delivery" or not request.user.is_approved:
            return Response({"detail":"Forbidden"}, status=403)
        try:
            lat=float(request.data["latitude"]); lng=float(request.data["longitude"])
            if not (-90 <= lat <= 90 and -180 <= lng <= 180): raise ValueError
        except (KeyError, TypeError, ValueError):
            return Response({"detail":"Valid coordinates required"}, status=400)
        p,_=DeliveryProfile.objects.get_or_create(user=request.user)
        p.current_latitude=lat; p.current_longitude=lng; p.last_location_at=timezone.now()
        p.save(update_fields=["current_latitude","current_longitude","last_location_at"])
        return Response({"updated":True,"last_location_at":p.last_location_at})
