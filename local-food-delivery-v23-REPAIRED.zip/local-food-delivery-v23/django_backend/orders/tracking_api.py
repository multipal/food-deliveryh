from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from .models import Order

class OrderTrackingView(APIView):
    permission_classes=[IsAuthenticated]
    def get(self, request, pk):
        try: o=Order.objects.get(pk=pk, customer=request.user)
        except Order.DoesNotExist: return Response({"detail":"Not found"}, status=404)
        data={"order_id":o.id,"status":o.status,"tracking_available":False}
        a=getattr(o,"delivery_assignment",None)
        if a:
            p=a.delivery_partner
            active=a.status not in ("DELIVERED","CANCELLED")
            data["delivery"]={"status":a.status,"tracking_available":active}
            if active and p.current_latitude is not None and p.current_longitude is not None:
                data["delivery"].update({"latitude":p.current_latitude,"longitude":p.current_longitude,"last_location_at":p.last_location_at})
                data["tracking_available"]=True
        return Response(data)
