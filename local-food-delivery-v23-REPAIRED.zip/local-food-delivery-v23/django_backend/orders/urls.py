from django.urls import path
from .views import OrderListCreateView, OrderDetailView, OrderStatusView
from .tracking_api import OrderTrackingView
urlpatterns=[
    path("",OrderListCreateView.as_view()),
    path("<int:pk>/",OrderDetailView.as_view()),
    path("<int:pk>/status/",OrderStatusView.as_view()),
    path("<int:pk>/tracking/",OrderTrackingView.as_view()),
]
