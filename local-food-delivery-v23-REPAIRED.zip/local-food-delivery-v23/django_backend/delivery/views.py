from django.db import transaction
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from .models import DeliveryProfile, DeliveryAssignment
from .serializers import DeliveryProfileSerializer, DeliveryAssignmentSerializer

class MyDeliveryProfileView(APIView):
    permission_classes=[IsAuthenticated]
    def get(self,request):
        if request.user.role!="delivery": return Response({"detail":"Forbidden"},status=403)
        p,_=DeliveryProfile.objects.get_or_create(user=request.user)
        return Response(DeliveryProfileSerializer(p).data)
    def patch(self,request):
        if request.user.role!="delivery": return Response({"detail":"Forbidden"},status=403)
        p,_=DeliveryProfile.objects.get_or_create(user=request.user)
        s=DeliveryProfileSerializer(p,data=request.data,partial=True); s.is_valid(raise_exception=True); s.save()
        return Response(s.data)

class MyAssignmentsView(APIView):
    permission_classes=[IsAuthenticated]
    def get(self,request):
        if request.user.role!="delivery": return Response({"detail":"Forbidden"},status=403)
        p,_=DeliveryProfile.objects.get_or_create(user=request.user)
        return Response(DeliveryAssignmentSerializer(DeliveryAssignment.objects.filter(delivery_partner=p),many=True).data)

class AssignmentAcceptView(APIView):
    permission_classes=[IsAuthenticated]
    @transaction.atomic
    def post(self,request,pk):
        if request.user.role!="delivery": return Response({"detail":"Forbidden"},status=403)
        p=DeliveryProfile.objects.select_for_update().get(user=request.user)
        a=DeliveryAssignment.objects.select_for_update().get(pk=pk)
        if a.delivery_partner_id!=p.id or a.status!="OFFERED" or not p.approved:
            return Response({"detail":"Assignment cannot be accepted"},status=409)
        a.status="ACCEPTED"; a.save(update_fields=["status"])
        p.available=False; p.save(update_fields=["available"])
        return Response(DeliveryAssignmentSerializer(a).data)
