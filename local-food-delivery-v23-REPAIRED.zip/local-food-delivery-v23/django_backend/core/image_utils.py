from io import BytesIO
from PIL import Image

def compress_to_target(image_file, target_kb=40, min_quality=25):
    """Returns a WebP BytesIO targeting <= target_kb where practical.
    Exact size is not guaranteed without unacceptable quality loss."""
    image=Image.open(image_file).convert("RGB")
    max_side=1200
    image.thumbnail((max_side,max_side),Image.Resampling.LANCZOS)
    best=None
    for size_factor in range(100,39,-10):
        if size_factor<100:
            w=max(240,int(image.width*size_factor/100))
            h=max(240,int(image.height*size_factor/100))
            test=image.resize((w,h),Image.Resampling.LANCZOS)
        else:
            test=image
        for q in range(82,min_quality-1,-4):
            out=BytesIO()
            test.save(out,format="WEBP",quality=q,method=6)
            if best is None or len(out.getvalue())<len(best.getvalue()):
                best=out
            if len(out.getvalue())<=target_kb*1024:
                out.seek(0); return out
    best.seek(0)
    return best
