from django.contrib import admin
from .models import PlatformSetting, Coupon, PlatformAd
admin.site.register(PlatformSetting)
admin.site.register(Coupon)
@admin.register(PlatformAd)
class PlatformAdAdmin(admin.ModelAdmin):
    list_display=("title","placement","active","priority","created_at")
    list_filter=("placement","active")
