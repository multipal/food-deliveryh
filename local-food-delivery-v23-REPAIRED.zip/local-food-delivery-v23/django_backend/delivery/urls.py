from django.urls import path
from .views import MyDeliveryProfileView, MyAssignmentsView, AssignmentAcceptView
from .location_api import LocationUpdateView
from .status_api import AssignmentStatusView
urlpatterns=[
    path("me/",MyDeliveryProfileView.as_view()),
    path("assignments/",MyAssignmentsView.as_view()),
    path("assignments/<int:pk>/accept/",AssignmentAcceptView.as_view()),
    path("location/",LocationUpdateView.as_view()),
    path("assignments/<int:pk>/status/",AssignmentStatusView.as_view()),
]
