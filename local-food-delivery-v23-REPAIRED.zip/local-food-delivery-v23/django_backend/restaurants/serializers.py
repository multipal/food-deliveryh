from rest_framework import serializers
from .models import Restaurant, Product

class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model=Product
        fields=["id","name","description","price","available","image"]

class RestaurantSerializer(serializers.ModelSerializer):
    products=ProductSerializer(many=True,read_only=True)
    class Meta:
        model=Restaurant
        fields=["id","name","description","address","latitude","longitude","status","is_open","products"]
        read_only_fields=["status"]
