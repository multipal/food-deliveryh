# Orders API

POST /api/v1/orders
GET  /api/v1/orders
GET  /api/v1/orders/{id}

Restaurant:
PATCH /api/v1/orders/{id}/status
Allowed: ACCEPTED, PREPARING, READY

Delivery:
PATCH /api/v1/orders/{id}/status
Allowed: PICKED_UP, OUT_FOR_DELIVERY, DELIVERED

Admin:
Can inspect and manage all orders.

Customer:
Can inspect only their own orders.

Server must reject illegal transitions and never trust a client-supplied role.
