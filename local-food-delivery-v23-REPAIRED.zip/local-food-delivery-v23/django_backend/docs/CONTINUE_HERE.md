# Continue Here — V21

Latest version: V21.

V21 focuses on go-live/deployment preparation. The next work should be real hosting setup, PostgreSQL production configuration, domain/HTTPS, payment production keys, WhatsApp/SMS provider, monitoring, backups, and final end-to-end testing.

Do not put secrets in the ZIP or source repository.
