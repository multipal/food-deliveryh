from django.db import transaction
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import User
from restaurants.models import Restaurant
from delivery.models import DeliveryProfile

class AdminOnlyMixin:
    def admin_ok(self, request):
        return request.user.is_authenticated and request.user.role == "admin"

class PendingApplicationsView(AdminOnlyMixin, APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        if not self.admin_ok(request):
            return Response({"detail": "Forbidden"}, status=403)
        users = User.objects.filter(role__in=["restaurant", "delivery"], is_approved=False).order_by("date_joined")
        result = []
        for u in users:
            r = Restaurant.objects.filter(owner=u).first()
            p = DeliveryProfile.objects.filter(user=u).first()
            result.append({
                "id": u.id, "username": u.username, "email": u.email, "phone": u.phone,
                "role": u.role, "restaurant": ({"id": r.id, "name": r.name, "address": r.address, "status": r.status} if r else None),
                "delivery_profile": ({"id": p.id} if p else None),
            })
        return Response(result)

class ApproveApplicationView(AdminOnlyMixin, APIView):
    permission_classes = [IsAuthenticated]

    @transaction.atomic
    def post(self, request, pk):
        if not self.admin_ok(request):
            return Response({"detail": "Forbidden"}, status=403)
        try:
            user = User.objects.select_for_update().get(pk=pk, role__in=["restaurant", "delivery"])
        except User.DoesNotExist:
            return Response({"detail": "Application not found"}, status=404)
        if user.is_approved:
            return Response({"approved": True, "user_id": user.id, "role": user.role})
        user.is_approved = True
        user.save(update_fields=["is_approved"])
        if user.role == "restaurant":
            r = Restaurant.objects.filter(owner=user).first()
            if not r:
                return Response({"detail": "Restaurant profile is missing."}, status=409)
            r.status = "approved"
            r.save(update_fields=["status"])
        else:
            p, _ = DeliveryProfile.objects.get_or_create(user=user)
            p.approved = True
            p.save(update_fields=["approved"])
        return Response({"approved": True, "user_id": user.id, "role": user.role})

class RejectApplicationView(AdminOnlyMixin, APIView):
    permission_classes = [IsAuthenticated]

    @transaction.atomic
    def post(self, request, pk):
        if not self.admin_ok(request):
            return Response({"detail": "Forbidden"}, status=403)
        try:
            user = User.objects.select_for_update().get(pk=pk, role__in=["restaurant", "delivery"])
        except User.DoesNotExist:
            return Response({"detail": "Application not found"}, status=404)
        if user.role == "restaurant":
            r = Restaurant.objects.filter(owner=user).first()
            if r:
                r.status = "rejected"
                r.save(update_fields=["status"])
        user.is_approved = False
        user.save(update_fields=["is_approved"])
        return Response({"rejected": True, "user_id": user.id})
