from django.urls import path
from .views import RegisterView, LoginView, LogoutView, MeView
from .role_application import ApplyRoleView
from .admin_api import PendingApplicationsView, ApproveApplicationView, RejectApplicationView

urlpatterns=[
    path("register/",RegisterView.as_view()),
    path("login/",LoginView.as_view()),
    path("logout/",LogoutView.as_view()),
    path("me/",MeView.as_view()),
    path("apply-role/",ApplyRoleView.as_view()),
    path("admin/applications/",PendingApplicationsView.as_view()),
    path("admin/applications/<int:pk>/approve/",ApproveApplicationView.as_view()),
    path("admin/applications/<int:pk>/reject/",RejectApplicationView.as_view()),
]
