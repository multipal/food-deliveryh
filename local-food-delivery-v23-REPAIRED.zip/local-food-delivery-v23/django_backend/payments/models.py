from django.conf import settings
from django.db import models
from orders.models import Order

class Payment(models.Model):
    METHOD=[('COD','Cash on Delivery'),('ONLINE','Online')]
    STATUS=[('PENDING','Pending'),('SUCCESS','Success'),('FAILED','Failed'),('REFUNDED','Refunded')]
    order=models.OneToOneField(Order,on_delete=models.PROTECT,related_name='payment')
    customer=models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.PROTECT,related_name='payments')
    method=models.CharField(max_length=20,choices=METHOD)
    status=models.CharField(max_length=20,choices=STATUS,default='PENDING')
    amount=models.DecimalField(max_digits=10,decimal_places=2)
    provider=models.CharField(max_length=50,default='internal')
    provider_payment_id=models.CharField(max_length=120,blank=True)
    created_at=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now=True)
