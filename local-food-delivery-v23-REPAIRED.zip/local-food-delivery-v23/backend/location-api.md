# Location / Eligibility

POST /api/v1/location/check-service

Input:
{
  "customer_latitude": 0,
  "customer_longitude": 0,
  "restaurant_id": 123
}

Server calculates distance using a geospatial distance formula and the configured service radius.

Important:
- The calculation happens on the server.
- Customer response should only contain eligible/not-eligible or eligible restaurants.
- Do not return exact distance or the 15 KM radius to the customer UI.
- Admin can configure the radius.
