from django.contrib import admin
from .models import DeliveryProfile, DeliveryAssignment
admin.site.register(DeliveryProfile)
admin.site.register(DeliveryAssignment)
