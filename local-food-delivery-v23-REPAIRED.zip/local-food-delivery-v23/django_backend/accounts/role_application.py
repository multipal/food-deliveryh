from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import User
from restaurants.models import Restaurant
from delivery.models import DeliveryProfile

class ApplyRoleView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        role = request.data.get("role")
        if role not in ("restaurant", "delivery"):
            return Response({"detail": "role must be restaurant or delivery"}, status=400)
        if request.user.role != "customer":
            return Response({"detail": "Only customer accounts can apply."}, status=409)

        user = request.user

        if role == "restaurant":
            required = ["name", "address", "latitude", "longitude"]
            if any(not request.data.get(k) for k in required):
                return Response({"detail": "Restaurant name, address and coordinates are required."}, status=400)
            try:
                latitude = float(request.data["latitude"]); longitude = float(request.data["longitude"])
                if not (-90 <= latitude <= 90 and -180 <= longitude <= 180): raise ValueError
            except Exception:
                return Response({"detail": "Valid latitude/longitude are required."}, status=400)

        user.role = role
        user.is_approved = False
        user.save(update_fields=["role", "is_approved"])

        if role == "restaurant":
            Restaurant.objects.update_or_create(
                owner=user,
                defaults={
                    "name": request.data["name"],
                    "description": request.data.get("description", ""),
                    "address": request.data["address"],
                    "latitude": latitude,
                    "longitude": longitude,
                    "status": "pending",
                },
            )
        else:
            DeliveryProfile.objects.get_or_create(user=user, defaults={"approved": False})

        return Response({"submitted": True, "role": role, "approved": False}, status=201)
