from django.conf import settings
from django.db import models
from orders.models import Order

class DeliveryProfile(models.Model):
    user=models.OneToOneField(settings.AUTH_USER_MODEL,on_delete=models.CASCADE,related_name="delivery_profile")
    approved=models.BooleanField(default=False)
    online=models.BooleanField(default=False)
    available=models.BooleanField(default=True)
    current_latitude=models.FloatField(null=True,blank=True)
    current_longitude=models.FloatField(null=True,blank=True)
    last_location_at=models.DateTimeField(null=True,blank=True)
    created_at=models.DateTimeField(auto_now_add=True)

class DeliveryAssignment(models.Model):
    STATUS=[("OFFERED","Offered"),("ACCEPTED","Accepted"),("PICKED_UP","Picked Up"),("OUT_FOR_DELIVERY","Out for Delivery"),("DELIVERED","Delivered"),("CANCELLED","Cancelled")]
    order=models.OneToOneField(Order,on_delete=models.CASCADE,related_name="delivery_assignment")
    delivery_partner=models.ForeignKey(DeliveryProfile,on_delete=models.PROTECT,related_name="assignments")
    status=models.CharField(max_length=30,choices=STATUS,default="OFFERED")
    assigned_at=models.DateTimeField(auto_now_add=True)
