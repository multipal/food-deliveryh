# Local Food Delivery — Continue Here

## Repaired V23
- Fixed missing accounts/0001, restaurants/0001 and delivery/0001 migrations.
- Removed the broken delivery/0002 dependency.
- Master Admin can change website name and logo URL.
- Master Admin can create, enable and disable first-party platform ads.
- AdSense settings are prepared; enable only after Google approval.
- Customer pages load branding and active first-party ads from the backend.
- Customer never receives service radius or exact distance.

## Start
Install `django_backend/requirements.txt`, then run `python manage.py migrate` and `python manage.py runserver` from `django_backend`.
