from django.db import migrations, models
import django.db.models.deletion
from django.conf import settings

class Migration(migrations.Migration):
    initial=True
    dependencies=[('orders','0001_initial'),migrations.swappable_dependency(settings.AUTH_USER_MODEL)]
    operations=[migrations.CreateModel(name='Payment',fields=[
        ('id',models.BigAutoField(auto_created=True,primary_key=True,serialize=False,verbose_name='ID')),
        ('method',models.CharField(choices=[('COD','Cash on Delivery'),('ONLINE','Online')],max_length=20)),
        ('status',models.CharField(choices=[('PENDING','Pending'),('SUCCESS','Success'),('FAILED','Failed'),('REFUNDED','Refunded')],default='PENDING',max_length=20)),
        ('amount',models.DecimalField(decimal_places=2,max_digits=10)),('provider',models.CharField(default='internal',max_length=50)),
        ('provider_payment_id',models.CharField(blank=True,max_length=120)),('created_at',models.DateTimeField(auto_now_add=True)),('updated_at',models.DateTimeField(auto_now=True)),
        ('customer',models.ForeignKey(on_delete=django.db.models.deletion.PROTECT,related_name='payments',to=settings.AUTH_USER_MODEL)),
        ('order',models.OneToOneField(on_delete=django.db.models.deletion.PROTECT,related_name='payment',to='orders.order')),
    ])]
