from django.db import transaction
from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from .models import Order, OrderItem
from restaurants.models import Product
from .serializers import OrderSerializer
from core.admin_api import setting

ROLE_STATUS={
 "restaurant":{"ACCEPTED","PREPARING","READY"},
 "delivery":{"PICKED_UP","OUT_FOR_DELIVERY","DELIVERED"},
 "admin":{"ACCEPTED","PREPARING","READY","PICKED_UP","OUT_FOR_DELIVERY","DELIVERED","CANCELLED"},
}
class OrderListCreateView(generics.ListCreateAPIView):
    permission_classes=[IsAuthenticated]
    serializer_class=OrderSerializer
    def get_queryset(self):
        u=self.request.user
        if u.role=="customer": return Order.objects.filter(customer=u).order_by("-created_at")
        if u.role=="restaurant": return Order.objects.filter(restaurant__owner=u).order_by("-created_at")
        return Order.objects.all().order_by("-created_at")
    def create(self, request, *args, **kwargs):
        from rest_framework.exceptions import ValidationError, PermissionDenied
        from decimal import Decimal
        from restaurants.models import Restaurant
        if request.user.role!="customer":
            raise PermissionDenied("Only customers can place orders.")
        try:
            restaurant=Restaurant.objects.get(id=int(request.data["restaurant_id"]),status="approved",is_open=True)
            lat=float(request.data["delivery_latitude"]); lng=float(request.data["delivery_longitude"])
        except Exception:
            raise ValidationError("Valid restaurant and location are required.")
        if restaurant.distance_km(lat,lng)>15:
            raise ValidationError("Delivery is not available for this location.")
        items=request.data.get("items",[])
        if not items: raise ValidationError("Cart is empty.")
        subtotal=Decimal("0"); clean=[]
        for item in items:
            try:
                p=Product.objects.get(id=int(item["product_id"]),restaurant=restaurant,available=True)
                q=max(1,int(item.get("quantity",1)))
            except Exception: raise ValidationError("Invalid product.")
            subtotal += p.price*q; clean.append((p,q))
        if subtotal < Decimal(setting("minimum_order")):
            raise ValidationError(f"Minimum order is {setting('minimum_order')}")
        fee=Decimal(setting("delivery_fee"))
        commission=(subtotal * Decimal(setting("commission")) / Decimal("100")).quantize(Decimal("0.01"))
        order=Order.objects.create(customer=request.user,restaurant=restaurant,status="PLACED",
            delivery_address=request.data.get("delivery_address",""),
            delivery_latitude=lat,delivery_longitude=lng,subtotal=subtotal,delivery_fee=fee,total=subtotal+fee,commission=commission)
        for p,q in clean: OrderItem.objects.create(order=order,product=p,quantity=q,price=p.price)
        return Response(OrderSerializer(order).data,status=201)

class OrderDetailView(generics.RetrieveAPIView):
    permission_classes=[IsAuthenticated]
    serializer_class=OrderSerializer
    queryset=Order.objects.all()
    def get_queryset(self):
        u=self.request.user
        if u.role=="customer": return Order.objects.filter(customer=u)
        if u.role=="restaurant": return Order.objects.filter(restaurant__owner=u)
        return Order.objects.all()

class OrderStatusView(APIView):
    permission_classes=[IsAuthenticated]
    @transaction.atomic
    def patch(self, request, pk):
        try: order=Order.objects.select_for_update().get(pk=pk)
        except Order.DoesNotExist: return Response({"detail":"Order not found"},status=404)
        role=request.user.role
        if role=="restaurant" and order.restaurant.owner_id!=request.user.id:
            return Response({"detail":"Forbidden"},status=403)
        allowed=ROLE_STATUS.get(role,set())
        new=request.data.get("status")
        if new not in allowed: return Response({"detail":"Status not allowed for this role"},status=403)
        order.status=new; order.save(update_fields=["status"])
        if new=="READY":
            from delivery.assignment_service import assign_ready_order
            assign_ready_order(order)
        return Response(OrderSerializer(order).data)
