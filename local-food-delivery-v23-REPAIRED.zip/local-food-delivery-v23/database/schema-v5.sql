-- V5 security/auth/assignment additions
CREATE TABLE users (
 id BIGINT PRIMARY KEY,
 name VARCHAR(120) NOT NULL,
 phone VARCHAR(30) UNIQUE NOT NULL,
 email VARCHAR(255) UNIQUE,
 password_hash TEXT NOT NULL,
 role VARCHAR(20) NOT NULL CHECK (role IN ('customer','restaurant','delivery','admin')),
 status VARCHAR(20) NOT NULL DEFAULT 'pending',
 created_at TIMESTAMP NOT NULL,
 updated_at TIMESTAMP NOT NULL
);

CREATE TABLE delivery_profiles (
 id BIGINT PRIMARY KEY,
 user_id BIGINT UNIQUE NOT NULL,
 vehicle_type VARCHAR(40),
 vehicle_number VARCHAR(60),
 verification_status VARCHAR(20) NOT NULL DEFAULT 'pending',
 is_online BOOLEAN NOT NULL DEFAULT FALSE,
 is_available BOOLEAN NOT NULL DEFAULT FALSE,
 latitude DECIMAL(10,7),
 longitude DECIMAL(10,7),
 created_at TIMESTAMP NOT NULL,
 updated_at TIMESTAMP NOT NULL
);

CREATE TABLE order_assignments (
 id BIGINT PRIMARY KEY,
 order_id BIGINT UNIQUE NOT NULL,
 delivery_user_id BIGINT NOT NULL,
 status VARCHAR(20) NOT NULL DEFAULT 'OFFERED',
 assigned_at TIMESTAMP NOT NULL,
 accepted_at TIMESTAMP,
 completed_at TIMESTAMP
);
