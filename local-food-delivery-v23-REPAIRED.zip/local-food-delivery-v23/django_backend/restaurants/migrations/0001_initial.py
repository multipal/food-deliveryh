from django.db import migrations, models
import django.db.models.deletion
class Migration(migrations.Migration):
 initial=True
 dependencies=[('accounts','0001_initial')]
 operations=[
 migrations.CreateModel(name='Restaurant',fields=[('id',models.BigAutoField(auto_created=True,primary_key=True,serialize=False,verbose_name='ID')),('name',models.CharField(max_length=160)),('description',models.TextField(blank=True)),('address',models.TextField()),('latitude',models.FloatField()),('longitude',models.FloatField()),('status',models.CharField(choices=[('pending','Pending'),('approved','Approved'),('rejected','Rejected'),('suspended','Suspended')],default='pending',max_length=20)),('is_open',models.BooleanField(default=True)),('created_at',models.DateTimeField(auto_now_add=True)),('owner',models.ForeignKey(on_delete=django.db.models.deletion.CASCADE,related_name='restaurants',to='accounts.user'))]),
 migrations.CreateModel(name='Product',fields=[('id',models.BigAutoField(auto_created=True,primary_key=True,serialize=False,verbose_name='ID')),('name',models.CharField(max_length=160)),('description',models.TextField(blank=True)),('price',models.DecimalField(decimal_places=2,max_digits=10)),('available',models.BooleanField(default=True)),('image',models.ImageField(blank=True,null=True,upload_to='products/')),('created_at',models.DateTimeField(auto_now_add=True)),('restaurant',models.ForeignKey(on_delete=django.db.models.deletion.CASCADE,related_name='products',to='restaurants.restaurant'))])]
