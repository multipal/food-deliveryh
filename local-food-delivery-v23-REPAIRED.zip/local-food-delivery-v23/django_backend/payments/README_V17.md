# V17 — Razorpay Online Payment Integration

- Server creates Razorpay orders using the server-side Order total.
- Customer verifies the returned Razorpay payment signature through the backend.
- Webhook signature is checked using `RAZORPAY_WEBHOOK_SECRET`.
- Real credentials are never stored in source code.

Environment variables:
`RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET`.

Install dependency with `pip install -r requirements.txt`.

Endpoints:
- `POST /api/v1/payments/orders/<order_id>/gateway-order/`
- `POST /api/v1/payments/orders/<order_id>/verify/`
- `POST /api/v1/payments/razorpay/webhook/`

Use Razorpay Test Mode keys first. Never commit production keys to GitHub.
