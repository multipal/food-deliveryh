from django.db import transaction
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from .models import DeliveryProfile, DeliveryAssignment

TRANSITIONS = {
    "ACCEPTED": "PICKED_UP",
    "PICKED_UP": "OUT_FOR_DELIVERY",
    "OUT_FOR_DELIVERY": "DELIVERED",
}

class AssignmentStatusView(APIView):
    permission_classes = [IsAuthenticated]

    @transaction.atomic
    def post(self, request, pk):
        if request.user.role != "delivery" or not request.user.is_approved:
            return Response({"detail": "Forbidden"}, status=403)
        try:
            profile = DeliveryProfile.objects.select_for_update().get(user=request.user)
            assignment = DeliveryAssignment.objects.select_for_update().select_related("order").get(pk=pk)
        except (DeliveryProfile.DoesNotExist, DeliveryAssignment.DoesNotExist):
            return Response({"detail": "Not found"}, status=404)
        if assignment.delivery_partner_id != profile.id:
            return Response({"detail": "Assignment not yours"}, status=403)
        next_status = TRANSITIONS.get(assignment.status)
        if not next_status:
            return Response({"detail": "Invalid status transition"}, status=409)
        assignment.status = next_status
        assignment.save(update_fields=["status"])
        order = assignment.order
        order.status = next_status
        order.save(update_fields=["status"])
        if next_status == "DELIVERED":
            profile.available = True
            profile.online = True
            profile.save(update_fields=["available", "online"])
        return Response({"assignment_id": assignment.id, "status": assignment.status, "order_status": order.status})
