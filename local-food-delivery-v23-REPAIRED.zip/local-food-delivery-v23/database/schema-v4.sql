-- V4 order flow additions
CREATE TABLE orders (
  id BIGINT PRIMARY KEY,
  order_number VARCHAR(32) UNIQUE NOT NULL,
  customer_id BIGINT NOT NULL,
  restaurant_id BIGINT NOT NULL,
  subtotal DECIMAL(10,2) NOT NULL,
  delivery_fee DECIMAL(10,2) DEFAULT 0,
  discount DECIMAL(10,2) DEFAULT 0,
  total_amount DECIMAL(10,2) NOT NULL,
  payment_method VARCHAR(20) NOT NULL,
  payment_status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
  order_status VARCHAR(30) NOT NULL DEFAULT 'PLACED',
  delivery_address TEXT NOT NULL,
  delivery_latitude DECIMAL(10,7),
  delivery_longitude DECIMAL(10,7),
  created_at TIMESTAMP NOT NULL,
  updated_at TIMESTAMP NOT NULL
);
CREATE TABLE order_items (
  id BIGINT PRIMARY KEY,
  order_id BIGINT NOT NULL,
  product_id BIGINT NOT NULL,
  product_name_snapshot VARCHAR(255) NOT NULL,
  unit_price DECIMAL(10,2) NOT NULL,
  quantity INT NOT NULL,
  line_total DECIMAL(10,2) NOT NULL
);
