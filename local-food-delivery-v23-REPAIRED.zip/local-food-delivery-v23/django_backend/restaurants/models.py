from django.conf import settings
from django.db import models
from math import radians, sin, cos, asin, sqrt

class Restaurant(models.Model):
    STATUS=[("pending","Pending"),("approved","Approved"),("rejected","Rejected"),("suspended","Suspended")]
    owner=models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE,related_name="restaurants")
    name=models.CharField(max_length=160)
    description=models.TextField(blank=True)
    address=models.TextField()
    latitude=models.FloatField()
    longitude=models.FloatField()
    status=models.CharField(max_length=20,choices=STATUS,default="pending")
    is_open=models.BooleanField(default=True)
    created_at=models.DateTimeField(auto_now_add=True)

    def distance_km(self, lat, lng):
        r=6371.0
        dlat=radians(self.latitude-lat); dlng=radians(self.longitude-lng)
        a=sin(dlat/2)**2+cos(radians(lat))*cos(radians(self.latitude))*sin(dlng/2)**2
        return 2*r*asin(sqrt(a))

class Product(models.Model):
    restaurant=models.ForeignKey(Restaurant,on_delete=models.CASCADE,related_name="products")
    name=models.CharField(max_length=160)
    description=models.TextField(blank=True)
    price=models.DecimalField(max_digits=10,decimal_places=2)
    available=models.BooleanField(default=True)
    image=models.ImageField(upload_to="products/",blank=True,null=True)
    created_at=models.DateTimeField(auto_now_add=True)
