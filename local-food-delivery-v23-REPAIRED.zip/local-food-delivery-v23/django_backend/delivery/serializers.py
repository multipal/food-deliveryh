from rest_framework import serializers
from .models import DeliveryProfile, DeliveryAssignment
class DeliveryProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model=DeliveryProfile
        fields=["id","approved","online","available","current_latitude","current_longitude"]
        read_only_fields=["approved"]
class DeliveryAssignmentSerializer(serializers.ModelSerializer):
    class Meta:
        model=DeliveryAssignment
        fields=["id","order","delivery_partner","status","assigned_at"]
